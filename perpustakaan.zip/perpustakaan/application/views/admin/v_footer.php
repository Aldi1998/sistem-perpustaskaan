<script type="text/javascript">
		$(document).ready(function(){
		$('.table-datatable').DataTable();
		});
</script>

</body>
</html>