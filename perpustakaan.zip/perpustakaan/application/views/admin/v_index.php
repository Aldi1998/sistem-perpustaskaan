<div class="container">
	<div class="jumbotron text-center">
		<div class="col-sm-8 mx-auto">
			<h1>Selamat datang Di Sistem Informasi Perpustakaan Taman Literasi Sukabuku</h1>
		</div>
	</div>
	<div class="row">
		<div class="col-md-3">
			<div class="card bg-success text-white">
				<div class="card-body">
					<h1>
						<?php echo $this->m_data->get_data('buku')->num_rows(); ?>
						<div class="pull-right">
						<i class="fa fa-book"></i>
						</div>
					</h1>
					Buku
				</div>
			</div>
		</div>
	<div class="col-md-3">
		<div class="card bg-secondary text-white">
			<div class="card-body">
				<h1>
					<?php echo $this->m_data->get_data('anggota')->num_rows(); ?>
					<div class="pull-right">
					<i class="fa fa-users"></i>
					</div>
				</h1>
				Anggota
			</div>
		</div>
	</div>
<div class="col-md-3">
	<div class="card bg-danger text-white">
		<div class="card-body">
			<h1>
				<?php echo $this->m_data->get_data('peminjaman')->num_rows(); ?>
				<div class="pull-right">
				<i class="fa fa-book"></i>
				</div>
			</h1>
			Total Peminjaman
		</div>
	</div>
</div>
<div class="col-md-3">
	<div class="card bg-dark text-white">
		<div class="card-body">
			<h1>
				<?php echo $this->m_data->get_data('petugas')->num_rows(); ?>
				<div class="pull-right">
				<i class="fa fa-user"></i>
				</div>
			</h1>
			Petugas
		</div>
	</div>
</div>
<footer>
    <div class="login-box-body text-center"> 
    	<a style="color: black"> Copyright &copy; Sistem Perpustakaan TBM Sukabuku Taman Literasi - <?php echo date("Y");?>
    </div>
</footer>
</div>
</div>