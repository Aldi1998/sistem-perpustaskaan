<div class="container">
	<div class="card">
		<div class="card-header text-center">
			<h4>Kirim sms</h4>
		</div>
		<div class="card-body">
			<a href="<?php echo base_url().'petugas/anggota' ?>" class='btn btn-sm btnlight btn-outline-dark pull-right'><i class="fa fa-arrow-left"></i> Kembali</a>
			<br/>
		<br/>
			<form method="post" action="<?php echo base_url().'petugas/sendmsg';
			?>">
			<div class="form-group">
			<label class="font-weight-bold" for="no_tujuan">No Tujuan</label>
				<input type="number" class="form-control" name="no_tujuan" placeholder="Masukan No telepon" required="required"></input>	
			</div>
			<div class="form-group">
			<label class="font-weight-bold" for="isi_pesan">Isi pesan</label>
			<textarea class="form-control" name="isi_pesan" required="required" placeholder="Masukkan pesan"></textarea>
			</div>
				<input type="submit" class="btn btn-primary" value="Kirim">
			</form>
		</div>
	</div>
</div>